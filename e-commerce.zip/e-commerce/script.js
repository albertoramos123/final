document.addEventListener('DOMContentLoaded', function() {
    const alertButton = document.querySelector('#alertBtn');
    alertButton.addEventListener('click', function() {
        alert('Muito obrigado por visitar !');
    });
});

